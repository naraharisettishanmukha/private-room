# Private Video Room

A small one-host / one-guest live video room. The guest explicitly presses a button to request camera access. The app streams video live to the host and does not implement recording or storage.

## Run locally

1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` and create a room.

## Deploy to Render (free test deployment)

This repository includes `render.yaml` as a Render Blueprint. Push the complete folder to a GitHub repository, then:

1. Sign in to Render and choose **New + → Blueprint**.
2. Connect the GitHub repository containing this project.
3. Review the `private-video-room` web service and choose the Free plan.
4. Apply the Blueprint and wait for the deploy to finish.
5. Open the HTTPS `onrender.com` URL shown by Render. Create a room there and share the guest link.

Render free web services may sleep after 15 minutes without traffic and can take about a minute to wake. In-memory rooms are lost if the service restarts or sleeps. This is for testing, not production.

## Important privacy and production notes

- The guest must explicitly press **Enable camera** and grant browser permission. The page tells them when video is shared with the host.
- Video is live peer-to-peer WebRTC; this app does not record or persist video.
- The guest camera is video-only; no microphone is requested.
- The demo keeps room state in memory; rooms are lost when the server restarts.
- The included public STUN server alone is not sufficient for every network. Configure a TURN service for reliable connections across restrictive networks.
- Before public production use, add authentication, rate limiting, room expiration, monitoring, secure secret handling, and a TURN service.
