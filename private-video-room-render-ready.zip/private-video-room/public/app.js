const socket = io();
const $ = id => document.getElementById(id);
let roomId = null, hostToken = null, pc = null, localStream = null, role = null;
const rtcConfig = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
function show(id) { ['home','host','guest'].forEach(x => $(x).classList.toggle('hidden', x !== id)); }
function setHostStatus(s) { $('hostStatus').textContent = s; }
function stopMedia() {
  if (pc) { pc.ontrack = null; pc.onicecandidate = null; pc.close(); pc = null; }
  if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
  $('localVideo').srcObject = null; $('remoteVideo').srcObject = null;
}
function makePeer() {
  if (pc) pc.close();
  pc = new RTCPeerConnection(rtcConfig);
  pc.onicecandidate = e => { if (e.candidate) socket.emit('ice-candidate', e.candidate); };
  if (role === 'host') {
    pc.ontrack = e => { $('remoteVideo').srcObject = e.streams[0]; $('videoPlaceholder').classList.add('hidden'); setHostStatus('● Live video'); };
    pc.onconnectionstatechange = () => { if (pc && ['failed','disconnected','closed'].includes(pc.connectionState)) setHostStatus('Connection ended'); };
  }
  return pc;
}
async function createOffer() {
  if (!localStream) return;
  const peer = makePeer();
  localStream.getTracks().forEach(track => peer.addTrack(track, localStream));
  const offer = await peer.createOffer(); await peer.setLocalDescription(offer); socket.emit('offer', offer);
}

$('createRoom').onclick = async () => {
  $('createRoom').disabled = true;
  try {
    const res = await fetch('/api/rooms', { method: 'POST' });
    const data = await res.json(); roomId = data.roomId; hostToken = data.hostToken;
    const base = location.origin;
    $('guestLink').value = `${base}/?room=${roomId}&role=guest`;
    $('roomDetails').classList.remove('hidden');
  } catch { alert('Could not create room. Please try again.'); }
  finally { $('createRoom').disabled = false; }
};
$('copyLink').onclick = async () => { try { await navigator.clipboard.writeText($('guestLink').value); $('copyLink').textContent = 'Copied!'; } catch { $('guestLink').select(); document.execCommand('copy'); $('copyLink').textContent = 'Copied!'; } };
$('joinHost').onclick = () => {
  if (!roomId || !hostToken) return;
  role = 'host'; show('host'); setHostStatus('Waiting for guest…');
  socket.emit('join-room', { roomId, role, hostToken });
};
$('enableCamera').onclick = async () => {
  $('enableCamera').disabled = true; $('guestStatus').textContent = 'Requesting camera permission…';
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    $('localVideo').srcObject = localStream; $('guestPlaceholder').classList.add('hidden');
    $('guestStatus').textContent = 'Camera is on. The host can see your live video when connected.';
    $('leaveGuest').classList.remove('hidden');
    socket.emit('join-room', { roomId, role: 'guest' });
  } catch (err) {
    $('guestStatus').textContent = err.name === 'NotAllowedError' ? 'Camera permission was denied. You can allow it in your browser settings and try again.' : 'Could not access the camera. Check that a camera is connected and try again.';
    $('enableCamera').disabled = false;
  }
};
$('leaveGuest').onclick = () => { socket.emit('guest-left'); stopMedia(); $('guestStatus').textContent = 'You left the room. Your camera is off.'; $('leaveGuest').classList.add('hidden'); $('guestPlaceholder').classList.remove('hidden'); $('enableCamera').classList.remove('hidden'); $('enableCamera').disabled = false; };
$('endHost').onclick = () => { stopMedia(); location.href = location.pathname; };

socket.on('joined', data => { if (data.role === 'host') setHostStatus('Waiting for guest…'); });
socket.on('waiting-for-host', () => { $('guestStatus').textContent = 'Camera is on. Waiting for host to join…'; });
socket.on('host-ready', async () => { if (role === 'guest' && localStream) { $('guestStatus').textContent = 'Host connected. Your live video is being shared.'; try { await createOffer(); } catch { $('guestStatus').textContent = 'Could not start the video connection. Please leave and rejoin.'; } } });
socket.on('offer', async offer => {
  if (role !== 'host') return;
  try { const peer = makePeer(); await peer.setRemoteDescription(offer); const answer = await peer.createAnswer(); await peer.setLocalDescription(answer); socket.emit('answer', answer); setHostStatus('Connecting to guest…'); }
  catch { setHostStatus('Could not establish video connection'); }
});
socket.on('answer', async answer => { if (role === 'guest' && pc) { try { await pc.setRemoteDescription(answer); } catch {} } });
socket.on('ice-candidate', async candidate => { if (pc) { try { await pc.addIceCandidate(candidate); } catch {} } });
socket.on('guest-left', () => { stopMedia(); $('videoPlaceholder').classList.remove('hidden'); setHostStatus('Guest left'); });
socket.on('host-left', () => { stopMedia(); $('guestStatus').textContent = 'The host left. Your camera is off.'; $('leaveGuest').classList.add('hidden'); $('guestPlaceholder').classList.remove('hidden'); });
socket.on('room-error', message => { alert(message); stopMedia(); show('home'); });

const params = new URLSearchParams(location.search);
if (params.get('role') === 'guest' && params.get('room')) { roomId = params.get('room'); role = 'guest'; show('guest'); }
