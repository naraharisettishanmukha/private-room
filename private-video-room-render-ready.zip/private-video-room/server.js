const express = require('express');
const http = require('http');
const crypto = require('crypto');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const rooms = new Map();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

function token() { return crypto.randomBytes(24).toString('hex'); }
function roomCode() { return crypto.randomBytes(5).toString('hex'); }

app.post('/api/rooms', (_req, res) => {
  let id;
  do { id = roomCode(); } while (rooms.has(id));
  const hostToken = token();
  rooms.set(id, { hostToken, host: null, guest: null, createdAt: Date.now() });
  res.json({ roomId: id, hostToken });
});

io.on('connection', socket => {
  socket.on('join-room', ({ roomId, role, hostToken }) => {
    const room = rooms.get(String(roomId || ''));
    if (!room) return socket.emit('room-error', 'This room does not exist or has expired.');
    if (role === 'host') {
      if (hostToken !== room.hostToken) return socket.emit('room-error', 'Invalid host access link.');
      if (room.host && room.host !== socket.id) return socket.emit('room-error', 'The host is already connected.');
      room.host = socket.id;
      socket.data.roomId = roomId; socket.data.role = 'host';
      socket.join(roomId);
      socket.emit('joined', { role: 'host' });
      if (room.guest) io.to(room.guest).emit('host-ready');
      return;
    }
    if (role === 'guest') {
      if (room.guest && room.guest !== socket.id) return socket.emit('room-error', 'A guest is already using this room.');
      room.guest = socket.id;
      socket.data.roomId = roomId; socket.data.role = 'guest';
      socket.join(roomId);
      socket.emit('joined', { role: 'guest' });
      if (room.host) socket.emit('host-ready');
      else socket.emit('waiting-for-host');
      return;
    }
    socket.emit('room-error', 'Invalid room role.');
  });

  for (const event of ['offer', 'answer', 'ice-candidate']) {
    socket.on(event, payload => {
      const room = rooms.get(socket.data.roomId);
      if (!room || !socket.data.role) return;
      const target = socket.data.role === 'guest' ? room.host : room.guest;
      if (target) io.to(target).emit(event, payload);
    });
  }

  socket.on('guest-left', () => {
    const room = rooms.get(socket.data.roomId);
    if (room && room.guest === socket.id) {
      room.guest = null;
      if (room.host) io.to(room.host).emit('guest-left');
    }
  });

  socket.on('disconnect', () => {
    const id = socket.data.roomId;
    const room = rooms.get(id);
    if (!room) return;
    if (room.guest === socket.id) {
      room.guest = null;
      if (room.host) io.to(room.host).emit('guest-left');
    }
    if (room.host === socket.id) {
      room.host = null;
      if (room.guest) io.to(room.guest).emit('host-left');
    }
    // Remove unused rooms after both participants leave.
    if (!room.host && !room.guest) rooms.delete(id);
  });
});

server.listen(PORT, () => console.log(`Private Video Room running on http://localhost:${PORT}`));
